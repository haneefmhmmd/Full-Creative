export default[
    {
        lenderName : {
            logo : "./dist/images/1.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/2.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/3.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/4.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/5.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/6.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/7.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/8.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/1.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/2.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/3.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/4.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/5.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/6.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/7.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/8.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/1.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/2.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/3.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/4.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/5.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/6.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/7.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    },
    {
        lenderName : {
            logo : "./dist/images/8.png",
            info : "NMLS ID: 7707"
        },
        lenderAPR : {
            apr : "3.6% APR",
            date : "Mar 10"
        },
        lenderRate : {
            rate : "3.500% Rate",
            point : "1 Point",
            lock : "30 Race Lock"            
        }, 
        lenderFees : {
            price : "$898.09",
            point : "1 Point",
            lock : "30 Race Lock"   
        },
        lenderQuestions : {
            number : "(887) 407 - 37123",
            comment : "Toll-free, no obligations"
        },
    }
]