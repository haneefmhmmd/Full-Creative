  import {documentReady} from './actions';
  import {toggleHide} from './modules/helperFunctions';
  import generateSlider,{sliderControl} from './modules/slider';
  import popularGames from './modules/popularGames';
  import templateGenerator from './modules/templateGenerator';
  import weekGuest from './modules/weeklyGuest';
  import Glide from '@glidejs/glide';
  function callback(){
    const games = document.querySelector("#games");
    const gamesWrapper = document.querySelector(".games");
    const categories = document.querySelector("#categories");
    const categoriesWrapper = document.querySelector(".games__categories");
    const backgroundToggler = document.querySelector(".toggleBackground span");
    const sliderOneControllers = document.querySelectorAll('.sliderOne__slideControllers');
    const sliderTwoControllers = document.querySelectorAll('.sliderTwo__slideControllers');
    games.onclick = function(){
      toggleHide(gamesWrapper);
      }
    categories.onclick = function(){
      toggleHide(categoriesWrapper);
    }
    const gamesSection = document.querySelector('.Gameswrapper').children;
    window.viewGamesSection = function(index){
      for(let i=0 ; i<gamesSection.length ; i++){
        if(!(gamesSection[i].classList.contains('hide'))){
          gamesSection[i].classList.add('hide');
          gamesWrapper.children[i].classList.remove('active');
        }
      }
      gamesSection[index].classList.remove('hide');
      gamesWrapper.children[index].classList.add('active');
    } 

    const categoriesSection = document.querySelector('.categoriesWrapper').children;
    window.viewCategoriesSection = function(index){
      for(let i=0 ; i<categoriesSection.length ; i++){
        if(!(categoriesSection[i].classList.contains('hide'))){
          categoriesSection[i].classList.add('hide');
          categoriesWrapper.children[i].classList.remove('active');
        }
      }
      categoriesSection[index].classList.remove('hide');
      categoriesWrapper.children[index].classList.add('active');
      if(!categoriesSection[0].classList.contains('hide')){
        viewAction();
      }
    } 

    backgroundToggler.onclick = ()=>{
      backgroundToggler.children[0].classList.toggle('lightMode');
      document.querySelector('header').classList.toggle('light');
      document.querySelector('main').classList.toggle('light');
      if(backgroundToggler.children[0].classList.contains('lightMode')){
        backgroundToggler.previousElementSibling.innerHTML="Light Mode";
      }
      else{
        backgroundToggler.previousElementSibling.innerHTML="Dark Mode";
      }
    }

    function viewAction(){
      const sliderOneContainer = document.querySelector('#weeklyQuests');
      templateGenerator(weekGuest,sliderOneContainer,'weekQuest');
      const sliderTwoContainer = document.querySelector('#popularGames');
      templateGenerator(popularGames,sliderTwoContainer,'popularGames');
      
      const config = {
          type : "carousel",
          perView : 4
      }

      new Glide('.sliderOne',config).mount();
      new Glide('.sliderTwo',config).mount();
    }

      
    const dropDown_Option = document.querySelector('.dropdown__options');
    window.viewDropdown = function(){
      dropDown_Option.classList.toggle('hide');
    };
    const dropdown_Option_values = dropDown_Option.children;
    window.selectOption = function(optionNum){
      document.querySelector('.dropdown span').innerHTML = dropdown_Option_values[optionNum].innerHTML;
      dropDown_Option.classList.toggle('hide');      
    };
  }  
  
  documentReady(callback);