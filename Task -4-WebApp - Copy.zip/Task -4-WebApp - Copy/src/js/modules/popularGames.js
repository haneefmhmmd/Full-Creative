export default [
    {
        image : "./dist/images/popularImg1.png",
        header : "PUBG Mobile",
        content : "Deal 5000 damage to enemies with grenades.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/popularImg2.png",
        header : "Talking Tom Gol…",
        content : "Run 20,000 meters",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/popularImg3.png",
        header : "Guns of Boom",
        content : "Eliminate 10 opponents from sniper rifle.",
        points : "+150",
        energy : "-300"
    },
    {
        image : "./dist/images/popularImg4.png",
        header : "Shadow Fight 2",
        content : "Defeat your opponent without special moves.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/popularImg1.png",
        header : "PUBG Mobile",
        content : "Deal 5000 damage to enemies with grenades.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/popularImg2.png",
        header : "Talking Tom Gol…",
        content : "Run 20,000 meters",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/popularImg3.png",
        header : "Guns of Boom",
        content : "Eliminate 10 opponents from sniper rifle.",
        points : "+150",
        energy : "-300"
    },
    {
        image : "./dist/images/popularImg4.png",
        header : "Shadow Fight 2",
        content : "Defeat your opponent without special moves.",
        points : "+100",
        energy : "-300"
    }
]