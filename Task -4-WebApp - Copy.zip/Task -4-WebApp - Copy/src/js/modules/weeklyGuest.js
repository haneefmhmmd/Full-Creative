export default [
    {
        image : "./dist/images/questImg1.png",
        header : "PUBG Mobile",
        content : "Deal 5000 damage to enemies with grenades.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/questImg2.png",
        header : "Mayhem Combat",
        content : "Win 10 games per character Mike.",
        points : "+75",
        energy : "-200"
    },
    {
        image : "./dist/images/questImg3.png",
        header : "Burrito Bison: Launcha Libre",
        content : "Earn 10,000 сoins.",
        points : "+150",
        energy : "-400"
    },
    {
        image : "./dist/images/questImg4.png",
        header : "Battlelands Royale",
        content : "Eliminate 10 opponents.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/questImg1.png",
        header : "PUBG Mobile",
        content : "Deal 5000 damage to enemies with grenades.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/questImg2.png",
        header : "Mayhem Combat",
        content : "Win 10 games per character Mike.",
        points : "+75",
        energy : "-200"
    },
    {
        image : "./dist/images/questImg3.png",
        header : "Burrito Bison: Launcha Libre",
        content : "Earn 10,000 сoins.",
        points : "+150",
        energy : "-400"
    },
    {
        image : "./dist/images/questImg4.png",
        header : "Battlelands Royale",
        content : "Eliminate 10 opponents.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/questImg1.png",
        header : "PUBG Mobile",
        content : "Deal 5000 damage to enemies with grenades.",
        points : "+100",
        energy : "-300"
    },
    {
        image : "./dist/images/questImg2.png",
        header : "Mayhem Combat",
        content : "Win 10 games per character Mike.",
        points : "+75",
        energy : "-200"
    }
]